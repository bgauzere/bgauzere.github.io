Monoamine Oxydase (MAO) dataset (classification problem). The class are specified in the file dataset.ds. This dataset is composed of 68 molecules divided into two classes: 38 molecules inhibit the monoamine oxidase (antidepressant drugs) and 30 do not. 

# references
[1] https://brunl01.users.greyc.fr/CHEMISTRY/index.html#MAO
