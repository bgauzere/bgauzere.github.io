

import numpy as np
from scipy.io import loadmat

import networkx as nx
from rdkit import Chem
from rdkit.Chem import SanitizeMol
from rdkit.Chem import AllChem

from sklearn.preprocessing import StandardScaler


def loadCobraData(fname='./datasets/cobradat.mat'):
    """
    @author: Muhammet Balcilar
    LITIS Lab, Rouen, France
    muhammetbalcilar@gmail.com


    This script is the demonstration of how we can export extracted Cobra Dataset.
    You can write your own code by reading data from given dataset as well but we recommended you use our provided mat file

    Dataset consist of 111 different molecules graph connections global and atomic descriptors.

    Dataset consist of A,C,F,TT,Atom,Anames,Vnames,FILE,NAME variables. Here is their explanations.

    A :     List of Agencency matrix; It consist of 111  variable size of binary valued matrix
    C :     List of Connectivity matrix; It consist of 111 variable size of double valued matrix
    F :     111x28 dimensional matrix keeps the global moleculer descriptor of each molecule
    TT:     111 element of list. Each element is also matrix by number of atom of corresponding molecule row but 54 column
    Atom:   111 element list. Each element also differnet length of list as well. Keeps the atom names. Forinstance Atom[0][0] shows theh name of the atom of 1st molecules 1st atom.
    Anames: 54 length list ; keeps the name of atomic descriptor. Since we have 54 atomic descriptor it consist of 54 string
    Vnames: 28 length list ; keeps the name of global descriptor. Since we have 28 global descriptor it consist of 28 string
    FILE:   111 element of list. Keeps the file name of corresponding molecule
    NAME:   111 element of list. Keeps the molecule name of corresponding molecule

    """

    # read mat file
    mat = loadmat(fname)
    # make Adjagency and Connectivity matrixes as list
    A=[];C=[]
    for i in range(0,mat['A'].shape[0]):
        A.append(mat['A'][i][0])
        C.append(mat['C'][i][0])
    # read global features descriptors
    F=mat['F']

    # read global descr names
    Vnames=[]
    for i in range(0,mat['Vnames'][0].shape[0]):
        Vnames.append(mat['Vnames'][0][i][0])

    # read file name and molecule names
    FILE=[];NAME=[]
    for i in range(0,mat['FILE'].shape[0]):
        FILE.append(mat['FILE'][i][0][0])
        NAME.append(mat['NAME'][i][0][0])

    # read atomic descriptor name
    Anames=[]
    for i in range(0,mat['Anames'].shape[1]):
        Anames.append(mat['Anames'][0][i][0])
    # read atomic descriptors
    TT=[];Atom=[]
    for i in range(0,mat['TT'].shape[0]):
        TT.append(mat['TT'][i][0])
        SA=[]
        for j in range(0,mat['Atom'][i][0].shape[0]):
            SA.append(mat['Atom'][i][0][j][0][0])
        Atom.append(SA)
    #TT Atom Anames 
    data_dict = {'adjacency_matrices': A,   
                 'connectivity_matrices': C,
                 'graph_features': F[:,:-1],
                 'graph_electrophilicity': F[:,-1],
                 'atom_features': TT,
                 'atom_names': Atom,
                 'atom_features_names': Anames,
                 'graph_features_names': Vnames[:-1],
                 'file_names': FILE,
                 'mol_names': NAME}
    return data_dict

def clean_cobra_graph_data(cobra_dataset):
    # Retrieve paper experiments
    X_cobra_graph = np.array([x[:17] for x in cobra_dataset['graph_features']])
    n=X_cobra_graph.shape[0]
    families = np.zeros((n,3)) # MV, AV, CV
    for i,name in enumerate(cobra_dataset['file_names']):
        if "MV" in name:
            families[i,0] = 1
        elif "AV" in name:
            families[i,1] = 1
        elif "CV" in name:
            families[i,2] = 1
        else:
            print("Error in file name")
            break
    # concatenate with the graph features
    scaler = StandardScaler()
    X_cobra_graph = scaler.fit_transform(X_cobra_graph)
    
    X_cobra_graph = np.concatenate((X_cobra_graph,families),axis=1)
    
    return X_cobra_graph

def clean_cobra_atom_data(cobra_dataset):

    def transform_graph_features(atom_features):
        atom_features = np.delete(atom_features, 17, axis=1)  # delete column 17
        atom_features = atom_features[:,4:]
        d = atom_features.shape[1]
        graph_rep_atom = []
        for f in atom_features.T:
            graph_rep_atom.extend([np.min(f),
                                   np.max(f),
                                   np.mean(f),
                                   np.std(f)])
        return np.array(graph_rep_atom).reshape(d*4,)

    X_cobra_atom = np.array([transform_graph_features(x) for x in cobra_dataset['atom_features']])
    scaler = StandardScaler()
    X_cobra_atom = scaler.fit_transform(X_cobra_atom)

    return X_cobra_atom

def convert_attr_TU(l, table):
    idx = np.argmax(l)
    return table[idx]

def convert_node_attr_Mutagenicity(l):
    attr_table = {
    0: 'C',
    1: 'O',
    2: 'Cl',
    3: 'H',
    4: 'N',
    5: 'F',
    6: 'Br',
    7: 'S',
    8: 'P',
    9: 'I',
    10: 'Na',
    11: 'K',
    12: 'Li',
    13: 'Ca'}
    return convert_attr_TU(l, attr_table)

def convert_node_attr_MUTAG(l):
    attr_table = {0:'C',1:'N',2:'O',3:'F',4:'I',5:'Cl',6:'Br'}
    return convert_attr_TU(l, attr_table)


def convert_edge_attr_Mutagenicity(l):
    attr_table = {0:Chem.BondType.SINGLE,
                  1:Chem.BondType.DOUBLE,
                  2:Chem.BondType.TRIPLE}
    return convert_attr_TU(l, attr_table)

def convert_edge_attr_acyclic(l):
    attr_table = {'0':Chem.BondType.AROMATIC,
                  '1':Chem.BondType.SINGLE,
                  '2':Chem.BondType.DOUBLE,
                  '3':Chem.BondType.TRIPLE}
    return attr_table[l] 

def convert_features_names(graphs,
                            cv_node_attr = None,
                            old_name_node = "node",
                            new_name_node = "atom",
                            cv_edge_attr = None,
                            old_name_edge = "bond_type",
                            new_name_edge = "bond_type",
                            ):
    ## Effet de bord !!
    for g in graphs:
        if cv_node_attr is not None:
            new_values = {n:cv_node_attr(attr[old_name_node]) for n,attr in g.nodes(data=True)}
            nx.set_node_attributes(g, name=new_name_node, values=new_values)
        if cv_edge_attr is not None:
            new_edge_values = {(u,v):cv_edge_attr(attr[old_name_edge]) for u,v,attr in g.edges(data=True)}
            nx.set_edge_attributes(g, name=new_name_edge, values=new_edge_values)

def nx_to_rdkit(graph):
    '''
    Le graph doit etre au format RDKIT'''


    # Créer une molécule vide avec RDKit
    mol = Chem.RWMol()

    # Dictionnaire pour conserver une correspondance entre les nœuds de NetworkX et les atomes de RDKit
    node_to_atom = {}

    # Ajouter les atomes
    for node, data in graph.nodes(data=True):
        atom = Chem.Atom(data['atom_symbol'])
        atom_idx = mol.AddAtom(atom)
        node_to_atom[node] = atom_idx

    # Ajouter les liaisons
    for u, v, data in graph.edges(data=True):
        start_idx = node_to_atom[u]
        end_idx = node_to_atom[v]
        bond_type = data['bond_type']
        mol.AddBond(start_idx, end_idx, bond_type)

    # Convertir en molécule finale et retourner
    return mol.GetMol()

def mol_to_fp(mol):


    mol.UpdatePropertyCache()
    SanitizeMol(mol)
    # Calculer le Morgan fingerprint
    fp = AllChem.GetMorganFingerprintAsBitVect(mol, radius=2, nBits=1024)
    # Convertir le fingerprint en numpy.array
    fp_array = np.array(list(fp))

    # Afficher le fingerprint  
    return fp_array


def compute_embeddings(graphs):
     convert_features_names(graphs,cv_node_attr=None, cv_edge_attr=convert_edge_attr_acyclic)
     return np.array([mol_to_fp(nx_to_rdkit(g)) for g in graphs])

def load_cobra_graph_data():
    cobra_dataset = loadCobraData(fname='./datasets/cobradat_nonnan.mat')
    X_cobra_graph = clean_cobra_graph_data(cobra_dataset)
    y_cobra = cobra_dataset['graph_electrophilicity']
    return X_cobra_graph, y_cobra

def load_cobra_atom_data():
    cobra_dataset = loadCobraData(fname='./datasets/cobradat_nonnan.mat')
    X_cobra_atom = clean_cobra_atom_data(cobra_dataset)
    y_cobra = cobra_dataset['graph_electrophilicity']
    return X_cobra_atom, y_cobra

def load_cobra_all_data():
    X_cobra_graph = load_cobra_graph_data()
    X_cobra_atom = load_cobra_atom_data()
    y_cobra = cobra_dataset['graph_electrophilicity']
    X_cobra_graph_atom = np.concatenate((X_cobra_graph,X_cobra_atom),axis=1)
    return X_cobra_graph_atom, y_cobra


if __name__ == '__main__':

    # Test du dataset cobra
    cobra_dataset = loadCobraData(fname='./datasets/cobradat.mat')

    # Lets reach some infomations
    print('Name of molecule: ', cobra_dataset['mol_names'][0])
    print('Name of file: ',cobra_dataset['file_names'][0])
    print('adjagency matrix:')
    print(cobra_dataset['adjacency_matrices'][0])
    print('Connectivity matrix:')
    print(cobra_dataset['connectivity_matrices'][0])
    print('Global features of the first molecule')
    for i in range(0,len(cobra_dataset['graph_features_names'])):
        print(cobra_dataset['graph_features_names'][i],'  = ', cobra_dataset['graph_features'][0,i])

    print('Atomic features of the first molecules 6th atom')

    print('Atom Name: ',  cobra_dataset['atom_names'][0][5])
    for i in range(0,cobra_dataset['atom_features'][0].shape[1]):
        print(cobra_dataset['atom_features_names'][i],' = ', cobra_dataset['atom_features'][0][5,i])